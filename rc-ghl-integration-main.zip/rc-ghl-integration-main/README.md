# RingCentral ↔ GoHighLevel Integration

Node service that receives RingCentral voicemail webhooks, fetches transcription/recording, and upserts a contact + note into GoHighLevel.

## Quick Start

```bash
cp .env.example .env
npm install
npm run dev
open http://localhost:8080/health
```

## Deploy on Render

- New → Web Service → connect repo
- Build: `npm install`
- Start: `node src/server.js`
- Set env vars from `.env`

## GoHighLevel
- Agency Settings → API Keys → LeadConnector key
- Location ID from target sub-account
- Set `LEADCONNECTOR_API_KEY` and `LEADCONNECTOR_LOCATION_ID`

## RingCentral
- Generate JWT for voicemail extension → `RINGCENTRAL_JWT`
- Event Subscription: Message Store/Voicemail
- Delivery: `https://<your-app>.onrender.com/webhooks/ringcentral`
- Header: `x-signature: <SHARED_SECRET>`

