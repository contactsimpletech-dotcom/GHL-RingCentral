import crypto from "crypto";

export async function withRetry(fn, retries = 3, delay = 300) {
  let attempt = 0;
  while (attempt < retries) {
    try {
      return await fn();
    } catch (e) {
      attempt++;
      if (attempt >= retries) throw e;
      await new Promise(r => setTimeout(r, delay * attempt));
    }
  }
}

export function dedupeKey(id, ts, phone, text) {
  const h = crypto.createHash("sha256");
  h.update(String(id));
  h.update("|");
  h.update(String(ts));
  h.update("|");
  h.update(String(phone));
  h.update("|");
  h.update(String(text));
  return h.digest("hex");
}
