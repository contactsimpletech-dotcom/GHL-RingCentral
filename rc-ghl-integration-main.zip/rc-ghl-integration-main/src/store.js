import fs from "fs";
import path from "path";

const dataDir = path.join(process.cwd(), "data");
const filePath = path.join(dataDir, "processed.json");
let store = { processed: {} };

export function loadStore() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (fs.existsSync(filePath)) {
    try {
      const raw = fs.readFileSync(filePath, "utf8");
      store = JSON.parse(raw);
    } catch {
      store = { processed: {} };
    }
  }
}

export function alreadyProcessed(key) {
  return Boolean(store.processed[key]);
}

export function markProcessed(key) {
  store.processed[key] = Date.now();
  fs.writeFileSync(filePath, JSON.stringify(store, null, 2));
}
