export function verifySignature(req) {
  const token = req.headers["x-signature"];
  const expected = process.env.SHARED_SECRET || "";
  if (!expected) return true;
  return token && token === expected;
}
