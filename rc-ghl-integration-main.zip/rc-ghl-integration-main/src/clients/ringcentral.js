import axios from "axios";

const BASE_URL = process.env.RINGCENTRAL_BASE_URL || "https://platform.ringcentral.com";
const CLIENT_ID = process.env.RINGCENTRAL_CLIENT_ID || "";
const CLIENT_SECRET = process.env.RINGCENTRAL_CLIENT_SECRET || "";
const JWT = process.env.RINGCENTRAL_JWT || "";

async function getAccessToken() {
  try {
    const res = await axios.post(
      `${BASE_URL}/restapi/oauth/token`,
      new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: JWT
      }),
      {
        auth: { username: CLIENT_ID, password: CLIENT_SECRET },
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
      }
    );
    return res.data.access_token;
  } catch (err) {
    console.error("[RingCentral] Token exchange failed:", err?.response?.data || err.message);
    throw new Error("ringcentral_token_failed");
  }
}

async function api() {
  const token = await getAccessToken();
  return axios.create({
    baseURL: BASE_URL,
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
    timeout: 20000
  });
}

export async function fetchMessage(messageId) {
  const client = await api();
  const path = `/restapi/v1.0/account/~/extension/~/message-store/${messageId}`;
  const res = await client.get(path);
  const data = res.data || {};

  const transcription =
    data.transcription?.text ||
    data.subject ||
    null;

  const from = data.from?.phoneNumber || null;
  const ts = data.creationTime || null;

  let recordingUrl = null;
  if (Array.isArray(data.attachments)) {
    const rec = data.attachments.find(a => a.contentType && a.contentType.includes("audio"));
    if (rec && rec.uri) recordingUrl = rec.uri;
  }

  return { transcription, recordingUrl, from, timestamp: ts };
}

export async function getRingSenseInsights(recordingId) {
  try {
    const token = await getAccessToken();
    const url = `${BASE_URL}/ai/ringsense/v1/public/accounts/~/domains/pbx/records/${recordingId}/insights`;
    const res = await axios.get(url, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" }
    });
    return res.data;
  } catch (err) {
    console.error("[RingSense] Fetch insights failed:", err?.response?.data || err.message);
    return null;
  }
}
