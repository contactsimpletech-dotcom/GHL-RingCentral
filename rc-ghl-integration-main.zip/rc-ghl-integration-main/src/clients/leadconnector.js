import axios from "axios";

const BASE_URL =
  process.env.LEADCONNECTOR_BASE_URL || "https://services.leadconnectorhq.com";
const API_KEY = process.env.LEADCONNECTOR_API_KEY || "";
const LOCATION_ID = process.env.LEADCONNECTOR_LOCATION_ID || "";

function client() {
  const instance = axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      Accept: "application/json",
      "Content-Type": "application/json",
      Version: "2021-07-28",
    },
    timeout: 20000,
  });

  instance.interceptors.request.use((cfg) => {
    console.log("[LC][REQ]", cfg.method?.toUpperCase(), cfg.url);
    return cfg;
  });

  instance.interceptors.response.use(
    (res) => {
      console.log("[LC][RES]", res.status, res.config.url);
      return res;
    },
    (err) => {
      const status = err?.response?.status;
      const data = err?.response?.data || err.message;
      console.error("[LC][ERR]", status, err?.config?.url, data);
      return Promise.reject(err);
    }
  );

  return instance;
}

export async function upsertContact(payload) {
  try {
    if (!payload.phone && !payload.email) {
      console.warn("[LC][WARN] Missing phone/email — injecting fallback");
      payload.phone = "+00000000000"; // fallback placeholder
    }
    payload.locationId = payload.locationId || LOCATION_ID;

    const res = await client().post(`/contacts/upsert`, payload);
    const contactId =
      res.data?.contact?.id || res.data?.id || res.data?.data?.id || null;

    if (contactId) {
      console.log(`[LC][OK] upsertContact success: ${contactId}`);
    } else {
      console.warn("[LC][WARN] upsertContact completed but ID missing", res.data);
    }

    return contactId;
  } catch (err) {
    const errorData = err?.response?.data || err.message;
    console.error("[LC] upsertContact failed:", errorData);
    throw err;
  }
}
export async function addNote(contactId, note) {
  if (!contactId) {
    console.warn("[LC][WARN] addNote skipped — no contactId");
    return null;
  }

  try {
    const res = await client().post(`/contacts/${contactId}/notes`, {
      body: note,
      locationId: LOCATION_ID,
      source: "RingCentral Voicemail",
    });

    const noteId =
      res.data?.id || res.data?.note?.id || res.data?.data?.id || null;
    console.log(`[LC][OK] addNote success: contact=${contactId}, note=${noteId}`);
    return res.data;
  } catch (err) {
    const errorData = err?.response?.data || err.message;
    console.error("[LC] addNote failed:", errorData);
    throw err;
  }
}
