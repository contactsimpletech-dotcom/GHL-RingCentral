// --- Regex patterns ---
const emailRe = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i;
const phoneRe = /(\+?\d[\d\s\-().]{7,})/;
const companyRe = /\b(?:company|from|at)\s*[:\-]?\s*([A-Za-z0-9&.,' ]{2,})/i;
const addressRe = /\b(?:address|located at|at)\s*[:\-]?\s*([A-Za-z0-9#.,' \-]{6,})/i;
const nameRe = /\b(?:my name is|this is)\s+([A-Za-z ,.'-]{2,})/i;

// --- Helper: sanitize "spoken" or malformed emails ---
function extractAndNormalizeEmail(text = "") {
  if (!text) return null;

  // Step 1: Try to find a normal email first
  const directMatch = (text.match(emailRe) || [])[0];
  if (directMatch) return directMatch.toLowerCase();

  // Step 2: If not found, look for a "spoken" email pattern
  let spoken = text
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/\(at\)|\[at\]| at /gi, "@")
    .replace(/\(dot\)|\[dot\]| dot /gi, ".")
    .replace(/,+/g, ".")
    .replace(/[^a-z0-9@._-]/g, "");

  // Step 3: Validate format
  const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(spoken);
  return valid ? spoken : null;
}

// --- Helper: normalize phone numbers ---
function normalizePhone(phoneRaw) {
  if (!phoneRaw) return null;
  const digits = phoneRaw.replace(/[^\d+]/g, "");
  if (digits.length < 7) return null;
  return digits;
}

// --- Main Parser ---
export function parseTranscription(text = "") {
  if (!text || typeof text !== "string") return {};

  const email = extractAndNormalizeEmail(text);
  const phoneRaw = (text.match(phoneRe) || [])[0] || null;
  const phone = normalizePhone(phoneRaw);
  const company = (text.match(companyRe) || [])[1]?.trim() || null;
  const address = (text.match(addressRe) || [])[1]?.trim() || null;

  // --- Name Extraction ---
  let firstName = null, lastName = null;
  const nameMatch = (text.match(nameRe) || [])[1];
  if (nameMatch) {
    const parts = nameMatch.trim().split(/\s+/);
    firstName = parts[0] || null;
    lastName = parts.length > 1 ? parts.slice(1).join(" ") : null;
  }

  return { email, phone, company, address, firstName, lastName };
}
