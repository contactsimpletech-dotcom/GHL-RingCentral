import express from "express";
import morgan from "morgan";
import dotenv from "dotenv";
import crypto from "crypto";
import { parseTranscription } from "./parser.js";
import { withRetry, dedupeKey } from "./utils.js";
import { loadStore, alreadyProcessed, markProcessed } from "./store.js";
import * as lc from "./clients/leadconnector.js";
import * as rc from "./clients/ringcentral.js";

dotenv.config();
const app = express();

app.use(
  express.json({
    type: "*/*",
    limit: "2mb",
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  })
);

app.use(morgan("tiny"));
loadStore();

app.get("/health", (req, res) =>
  res.json({ ok: true, mode: (process.env.MODE || "live").toLowerCase() })
);
app.get("/", (req, res) => res.send("✅ RingCentral-GHL Integration is running"));

function isValidationPing(body) {
  if (!body || Object.keys(body).length === 0) return true;
  if (!body.body && !body.messageId && !body.id && !body.event) return true;
  return false;
}

function verifyRingCentralSignature(req) {
  const secret = (process.env.SHARED_SECRET || "").trim();
  if (!secret) return true;

  const signature =
    req.get("x-ringcentral-signature") ||
    req.headers["x-ringcentral-signature"];
  if (!signature) return false;

  const payload = req.rawBody ?? Buffer.from(JSON.stringify(req.body || {}));
  const expected = crypto
    .createHmac("sha256", secret)
    .update(payload)
    .digest("base64");

  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function sanitizeEmail(email) {
  if (!email) return "";
  let clean = email
    .replace(/\s+/g, "")
    .replace(/\(at\)|\[at\]| at /gi, "@")
    .replace(/\(dot\)|\[dot\]| dot /gi, ".")
    .replace(/,+/g, ".")
    .replace(/[^a-zA-Z0-9@._-]/g, "");
  const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean);
  return valid ? clean.toLowerCase() : "";
}

function normalizePhone(phone) {
  if (!phone) return "";
  let clean = phone.replace(/[^\d+]/g, "");
  if (!clean.startsWith("+")) {
    clean = "+1" + clean.replace(/^1+/, "");
  }
  const digits = clean.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) return "";
  return clean;
}

app.post("/webhooks/ringcentral", async (req, res) => {
  try {
    const validationToken =
      req.get("Validation-Token") || req.headers["validation-token"];
    if (validationToken) {
      res.set("Validation-Token", validationToken);
      return res.status(200).send("OK");
    }

    if (!verifyRingCentralSignature(req)) {
      console.warn("[WARN] Signature missing or invalid, skipping verification temporarily");
    }

    if (isValidationPing(req.body)) return res.status(200).send("OK");

    const body = req.body || {};
    const messageId =
      body.messageId ||
      body.id ||
      body?.body?.id ||
      body?.body?.message?.id ||
      null;
    const timestamp =
      body.timestamp ||
      body.creationTime ||
      body?.body?.creationTime ||
      new Date().toISOString();
    const fromNumber =
      body.from?.phoneNumber ||
      body.fromNumber ||
      body?.body?.from?.phoneNumber ||
      null;
    const msgType =
      body.type || body.eventType || body?.body?.type || "voicemail";

    const lowerType = String(msgType).toLowerCase();
    const isVoiceMail = lowerType.includes("voicemail");
    const isCall =
      lowerType.includes("call") ||
      (body?.event && body.event.includes("telephony.sessions"));

    if (!isVoiceMail && !isCall)
      return res.status(200).json({ ok: true, ignored: true });

    const key = dedupeKey(messageId || "", timestamp || "", fromNumber || "");
    if (alreadyProcessed(key))
      return res.status(200).json({ ok: true, duplicate: true });

    let transcription = body.transcription || body.transcriptionText || null;
    let recordingUrl = body.recordingUrl || body?.body?.recording?.uri || null;

    if ((!transcription || !recordingUrl) && messageId) {
      const details = await withRetry(() => rc.fetchMessage(messageId));
      if (!transcription) transcription = details?.transcription || null;
      if (!recordingUrl) recordingUrl = details?.recordingUrl || null;
    }

    const parsed = parseTranscription(transcription || "");

    let phone = normalizePhone(parsed.phone || fromNumber);
    if (!phone) phone = "+10000000000";

    if (!parsed.firstName) parsed.firstName = "Caller";
    if (!parsed.lastName) parsed.lastName = phone.slice(-4);

    const cleanEmail = sanitizeEmail(parsed.email || "");
    const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail);

    const contactPayload = {
      firstName: parsed.firstName || "Unknown",
      lastName: parsed.lastName || "Caller",
      phone: phone,
      address1: parsed.address || "",
      locationId: process.env.LEADCONNECTOR_LOCATION_ID || "",
      ...(validEmail ? { email: cleanEmail } : {}),
      customFields: parsed.company
        ? [{ name: "Company", value: parsed.company }]
        : [],
      tags: [isVoiceMail ? "RingCentral-Voicemail" : "RingCentral-Call"],
    };

    const contactId = await withRetry(() => lc.upsertContact(contactPayload));

    let noteLines = [];
    if (isVoiceMail)
      noteLines.push(`📩 Voicemail received: ${timestamp}`);
    else noteLines.push(`📞 Call recorded: ${timestamp}`);
    if (recordingUrl) noteLines.push(`🎧 Recording: ${recordingUrl}`);
    if (transcription) noteLines.push("📝 Transcription:\n" + transcription);

    if (recordingUrl) {
      const match = recordingUrl.match(/recording\/([A-Za-z0-9_-]+)/);
      const recordingId = match ? match[1] : null;
      if (recordingId) {
        const insights = await rc.getRingSenseInsights(recordingId);
        if (insights) {
          if (insights.summary)
            noteLines.push("\n🧠 AI Summary:\n" + insights.summary);
          if (insights.sentiment)
            noteLines.push("\n💬 Sentiment: " + insights.sentiment);
          if (insights.highlights?.length)
            noteLines.push("\n✨ Highlights:\n" + insights.highlights.join("; "));
        }
      }
    }

    const note = noteLines.join("\n\n");
    await withRetry(() => lc.addNote(contactId, note));
    markProcessed(key);

    return res.status(200).json({
      ok: true,
      contactId,
      parsed,
      notePreview: note.slice(0, 200) + (note.length > 200 ? "..." : ""),
    });
  } catch (e) {
    console.error("Webhook error:", e?.message || e);
    return res.status(200).json({ ok: true, warn: "handled_error" });
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () =>
  console.log(`🚀 Server listening on port ${port}`)
);
